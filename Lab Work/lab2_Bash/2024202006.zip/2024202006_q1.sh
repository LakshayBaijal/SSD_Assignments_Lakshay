#!/bin/bash

find / -name "john_doe_assignment.txt"| xargs cat | head -4
