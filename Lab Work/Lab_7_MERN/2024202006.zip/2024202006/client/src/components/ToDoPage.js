// File: client/src/components/ToDoPage.js

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../common.css";
import "./ToDoPage.css";

function ToDoPage() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState("");
  const navigate = useNavigate();

  const handleCreate = () => {
    if (new Date(date) <= new Date()) {
      alert("Please select a future date for the to-do item.");
      return;
    }
    alert(
      `To-Do Created:\nTitle: ${title}\nDescription: ${description}\nDate: ${date}`
    );
  };

  return (
    <div className="todo-page center-div">
      <h2 className="text-center">Create To-Do Item</h2>
      <div className="form-group">
        <label className="form-label">Title:</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="form-control input-field"
          placeholder="Enter title"
        />
      </div>
      <div className="form-group">
        <label className="form-label">Description:</label>
        <input
          type="text"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="form-control input-field"
          placeholder="Enter description"
        />
      </div>
      <div className="form-group">
        <label className="form-label">Completion Date:</label>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="form-control input-field"
        />
      </div>
      <button className="btn btn-primary create-btn" onClick={handleCreate}>
        Create To-Do
      </button>
    </div>
  );
}

export default ToDoPage;
