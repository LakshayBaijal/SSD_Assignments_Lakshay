use classicmodels;

/* I. Find the total sales per employee and list the top 3 employees by total sales using Common Table
Expressions */

