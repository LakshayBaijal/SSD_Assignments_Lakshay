use classicmodels;

/*T. Create a Common Table Expression to find the average sales amount per customer, and then list
customers who have spent more than twice the average. */ 