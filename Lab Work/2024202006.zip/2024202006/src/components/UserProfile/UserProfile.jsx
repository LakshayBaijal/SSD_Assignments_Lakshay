import React from "react";
import "./UserProfile.css";

// Destructure the `profile` prop directly
const UserProfile = ({ profile }) => {
  return (
    <div className="user-profile">
      {/* Display the user's name */}
      <h3>{profile.name}</h3>

      {/* Display the user's age */}
      <p>
        <strong>Age:</strong> {profile.age}
      </p>

      {/* Display the user's bio */}
      <p>
        <strong>Bio:</strong> {profile.bio}
      </p>
    </div>
  );
};

export default UserProfile;
