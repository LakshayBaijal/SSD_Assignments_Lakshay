import React, { useState } from "react";

// Import profiles.js (assuming it's an array of profile objects)
import profiles from "../../data/profiles";

// Import UserProfile component to display each user profile
import UserProfile from "../UserProfile/UserProfile"; // <-- Add this import

const Search = () => {
  // State for search input
  const [searchTerm, setSearchTerm] = useState("");

  // Function to filter profiles based on the search term
  const filteredProfiles = profiles.filter((profile) =>
    profile.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="search">
      <input
        type="text"
        placeholder="Search for profiles..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)} // Update state when the input changes
      />

      <div className="results">
        {/* Display the filtered results using the map function */}
        {filteredProfiles.length > 0 ? (
          filteredProfiles.map((profile) => (
            <UserProfile key={profile.id} profile={profile} />
          ))
        ) : (
          <p>No profiles found</p>
        )}
      </div>
    </div>
  );
};

export default Search;
