import React from "react";
import "./ProfilePage.css";

const ProfilePage = () => {
  // 1. Add a JavaScript object here
  const profile = {
    name: "Lakshay Baijal",
    age: 22,
    bio: "Software developer studying CSIS in IIITH ",
  };

  return (
    <div className="profile-container">
      <h1>Profile Page</h1>
      {/* 2. Access the object and render here */}
      <p>
        <strong>Name:</strong> {profile.name}
      </p>
      <p>
        <strong>Age:</strong> {profile.age}
      </p>
      <p>
        <strong>Bio:</strong> {profile.bio}
      </p>
    </div>
  );
};

export default ProfilePage;
