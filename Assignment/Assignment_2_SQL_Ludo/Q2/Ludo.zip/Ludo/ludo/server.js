const express = require("express");
const fs = require("fs");
const path = require("path");
const bodyParser = require("body-parser");

const app = express();
const PORT = 3000;

// Middleware to parse JSON body
app.use(bodyParser.json());

// Serve static files (index.html, ludo.js, models, etc.)
app.use(express.static(path.join(__dirname)));

// Endpoint to receive and log dice rolls
app.post("/log-dice-roll", (req, res) => {
  const { dice1, dice2 } = req.body;
  const logMessage = `Dice 1: ${dice1}, Dice 2: ${dice2}\n`;

  // Append the message to the logs.txt file
  fs.appendFile("logs.txt", logMessage, (err) => {
    if (err) {
      console.error("Error writing to log file:", err);
      return res.status(500).send("Failed to log dice roll.");
    }
    res.status(200).send("Dice roll logged successfully.");
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
