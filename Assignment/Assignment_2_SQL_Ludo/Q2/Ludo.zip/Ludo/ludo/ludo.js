const scene = new THREE.Scene();
scene.background = new THREE.Color(0xeeeeee);

const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);
camera.position.set(0, 150, 250);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.25;
controls.enableZoom = true;

const ambientLight = new THREE.AmbientLight(0xffffff, 2);
scene.add(ambientLight);

const directionalLight = new THREE.DirectionalLight(0xffffff, 1.5);
directionalLight.position.set(0, 150, 100);
directionalLight.castShadow = true;
scene.add(directionalLight);

const loader = new THREE.GLTFLoader();
loader.load(
  "./model/3d_ludo_king_game.glb",
  function (gltf) {
    const ludoBoard = gltf.scene;
    scene.add(ludoBoard);

    ludoBoard.position.set(0, 0, 0);
    ludoBoard.scale.set(50, 50, 50);
    ludoBoard.rotation.y = Math.PI / 2;

    animate();
  },
  undefined,
  function (error) {
    console.error("An error occurred while loading the GLB model:", error);
  }
);

function animate() {
  requestAnimationFrame(animate);

  controls.update();

  renderer.render(scene, camera);
}

window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

const diceElement = document.getElementById("dice");
const diceElement2 = document.getElementById("dice2");

function rollDice() {
  const diceRoll1 = Math.floor(Math.random() * 6) + 1;
  const diceRoll2 = Math.floor(Math.random() * 6) + 1;

  diceElement.src = `./model/Dice${diceRoll1}.png`;
  diceElement2.src = `./model/Dice${diceRoll2}.png`;

  fetch("/log-dice-roll", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ dice1: diceRoll1, dice2: diceRoll2 }),
  })
    .then((response) => response.text())
    .then((data) => console.log(data))
    .catch((error) => console.error("Error logging dice roll:", error));
}

diceElement.addEventListener("click", rollDice);
diceElement2.addEventListener("click", rollDice);
