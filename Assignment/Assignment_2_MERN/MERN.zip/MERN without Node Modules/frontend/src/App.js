import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import React, { useState, useEffect } from "react";
import axios from "axios";
import Product from "./components/Product";
import Cart from "./Cart";
import Checkout from "./Checkout";
import Login from "./components/Login";
import Register from "./components/Register";
import ProductDetail from "./ProductDetail";
import Dashboard from "./Dashboard";
import "./style.css";
function App() {

  const [userId, setUserId] = useState(null);

  const [products, setProducts] = useState([]);

  const [cart, setCart] = useState(() => {
    const savedCart = localStorage.getItem("cart");
    return savedCart ? JSON.parse(savedCart) : [];
  });

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/products")
      .then((res) => {
        console.log("Fetched products:", res.data); 
        setProducts(res.data);
      })
      .catch((err) => console.error(err));
  }, []);

  useEffect(() => {
    console.log("Saving cart to localStorage:", cart); 
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/auth/session")
      .then((res) => {
        if (res.data.userId) {
          setUserId(res.data.userId);
        }
      })
      .catch((err) => console.error(err));
  }, []);

  const addToCart = (product) => {
    console.log("Product added to cart:", product); 
    const existingProduct = cart.find((item) => item._id === product._id); 
    if (existingProduct) {

      console.log("Product exists in cart, updating quantity");
      updateQuantity(product.id, existingProduct.quantity + 1);
    } else {
      console.log("Product doesn't exist in cart, adding new item");
      setCart([...cart, { ...product, quantity: 1 }]);
    }
    console.log("Cart after update:", cart); 
  };

  const removeFromCart = (productId) => {
    console.log("Removing product with ID:", productId); 
    setCart(cart.filter((item) => item._id !== productId)); 
  };

  const updateQuantity = (id, quantity) => {
    setCart(
      cart.map((item) =>
        item._id === id ? { ...item, quantity: parseInt(quantity) } : item
      )
    ); 
  };

  const handleLogout = () => {
    axios
      .post("http://localhost:5000/api/auth/logout")
      .then(() => {
        setUserId(null);
      })
      .catch((err) => console.error(err));
  };

  const clearCart = () => {
    setCart([]);
    localStorage.removeItem("cart");
  };

  return (
    <Router>
      <div>
        {/* Navigation Links */}
        <nav>
          <Link to="/">Home</Link> | <Link to="/checkout">Checkout</Link> |{" "}
          <Link to="/dashboard">Dashboard</Link>
          {userId ? (
            <button onClick={handleLogout}>Logout</button>
          ) : (
            <>
              <Link to="/login">Login</Link> |{" "}
              <Link to="/register">Register</Link>
            </>
          )}
        </nav>

        {/* Routing for different pages */}
        <Routes>
          {/* Home Route: Displays product list and cart */}
          <Route
            path="/"
            element={
              <>
                <h1>Simple Shopping Cart</h1>
                <div>
                  {/* Render all products */}
                  {products.map((product) => (
                    <Product
                      key={product.id}
                      product={product}
                      addToCart={addToCart}
                    />
                  ))}
                </div>
                {/* Cart component */}
                <Cart
                  cart={cart}
                  removeFromCart={removeFromCart}
                  updateQuantity={updateQuantity}
                />
              </>
            }
          />

          {/* Product Detail Route */}
          <Route path="/product/:id" element={<ProductDetail />} />

          {/* Checkout Route */}
          <Route
            path="/checkout"
            element={
              <Checkout cart={cart} userId={userId} clearCart={clearCart} />
            }
          />

          {/* Login Route */}
          <Route path="/login" element={<Login setUserId={setUserId} />} />

          {/* Register Route */}
          <Route path="/register" element={<Register />} />

          {/* Dashboard Route */}
          <Route path="/dashboard" element={<Dashboard userId={userId} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
