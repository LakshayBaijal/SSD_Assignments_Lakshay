import React from "react";

function Cart({ cart, removeFromCart, updateQuantity }) {
  return (
    <div className="container">
      <h2>Your Cart</h2>
      {cart.length === 0 ? (
        <p>Cart is empty.</p>
      ) : (
        <>
          {cart.map((item) => (
            <div key={item._id} className="cart-item">
              <div>
                <h3>{item.name}</h3>
                <p>${item.price}</p>
              </div>
              <input
                type="number"
                value={item.quantity || 1}
                onChange={(e) => updateQuantity(item._id, e.target.value)}
                min="1"
                max="1000"
              />
              <button onClick={() => removeFromCart(item._id)}>Remove</button>
            </div>
          ))}
          <div className="cart-summary">
            <p>
              Total: $
              {cart
                .reduce(
                  (sum, item) => sum + item.price * (item.quantity || 1),
                  0
                )
                .toFixed(2)}
            </p>
          </div>
        </>
      )}
    </div>
  );
}

export default Cart;
