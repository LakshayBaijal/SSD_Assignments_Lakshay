import React from "react";
import axios from "axios";

function Checkout({ cart, userId, clearCart }) {
  const total = cart.reduce(
    (sum, item) => sum + item.price * (item.quantity || 1),
    0
  );

  const handlePlaceOrder = async () => {
    if (!userId) {
      alert("Please log in to place an order");
      return;
    }

    const orderData = {
      userId,
      items: cart,
      total,
    };

    console.log("Placing order with data:", orderData); 

    try {
      await axios.post("http://localhost:5000/api/orders", orderData);
      alert("Order placed successfully");
      clearCart(); 
    } catch (error) {
      console.error("Order placement failed:", error); 
      alert("Failed to place order");
    }
  };

  return (
    <div>
      <h2>Checkout</h2>
      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          <ul>
            {cart.map((item) => (
              <li key={item._id}>
                {item.name} - ${item.price} x {item.quantity || 1}
              </li>
            ))}
          </ul>
          <p>Total: ${total.toFixed(2)}</p>
          <button onClick={handlePlaceOrder}>Place Order</button>
        </>
      )}
    </div>
  );
}

export default Checkout;
