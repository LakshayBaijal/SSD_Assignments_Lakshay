import React, { useState, useEffect } from "react";
import axios from "axios";

function Dashboard({ userId }) {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    if (userId) {
      axios
        .get(`http://localhost:5000/api/orders/${userId}`)
        .then((res) => setOrders(res.data))
        .catch((err) => console.error(err));
    }
  }, [userId]);

  return (
    <div className="container">
      <h2>Your Order History</h2>
      {orders.length === 0 ? (
        <p>No orders found.</p>
      ) : (
        orders.map((order) => (
          <div key={order._id} className="order-history">
            <p>Order Date: {new Date(order.date).toLocaleString()}</p>
            <p>Total: ${order.total.toFixed(2)}</p>
            <ul>
              {order.items.map((item) => (
                <li key={item._id}>
                  {item.name} - ${item.price} x {item.quantity}
                </li>
              ))}
            </ul>
            <hr />
          </div>
        ))
      )}
    </div>
  );
}

export default Dashboard;
